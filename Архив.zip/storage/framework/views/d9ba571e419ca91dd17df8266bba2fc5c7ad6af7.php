<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Главный</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/look.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playball&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="css/respons.css	">
</head>
<body>
<div class="container">
    <div class="col-lg-12 pt-5 pb-5">
        <img src="images/MaccooBlack.svg" alt="">
    </div>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="col-lg-12" id="menu">
        <div class="row">
            <div>

                <div class="lik">

                    <a href="poisk.html" class="clr" style="display: flex;flex-flow: column;align-items: center;">
                        <img src="images/sery.svg">
                        <span>
								Поиск
							</span>
                    </a>
                </div>
            </div>
            <div>
                <div class="lik">

                    <a href="luis.html" class="clr" style="display: flex;flex-flow: column;align-items: center;">
                        <img src="images/Vector1.svg" alt="">
                        <span>
								Что нового
							</span>
                    </a>
                </div>
            </div>
            <div>
                <div class="lik">

                    <a href="" class="clr" style="display: flex;flex-flow: column;align-items: center;">
                        <img src="images/Vectorgl.svg" alt="">
                        <span class="kok">
								Главный
							</span>
                    </a>
                </div>
            </div>
            <div>
                <div class="lik">

                    <a href="section.html" class="clr" style="display: flex;flex-flow: column;align-items: center;">
                        <img src="images/Vector3.svg" alt="">
                        <span>
								Добавить
							</span>
                    </a>
                </div>
            </div>
            <div>
                <div class="lik">

                    <a href="profile.html" class="clr" style="display: flex;flex-flow: column;align-items: center;">
                        <img src="images/Vector4.svg" class="rlp">
                        <span>
								Профиль
							</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/Maccoo/resources/views/layouts/user.blade.php ENDPATH**/ ?>