<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    //
    public function Register(Request $request){
        $rules = [
          ''
        ];
        $messages = [

        ];
        $validator = $this->validator($request->all(),$rules,$messages);
        if ($validator->fails()){
            return back()->withErrors($validator->errors());
        }else{
            $user = new User();
            $user['email'] = $request['email'];
            $user['phone'] = $request['phone'];
            $user['name'] = $request['name'];
            $user['login'] = $request['login'];
            $user['password'] = $request['password'];
            $user->save();

            session()->put('user',$user);

            $data['user'] = $user;
            return view('main',$data)->with('message','Вы зарегистрировались');
        }
    }
}

