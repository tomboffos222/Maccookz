@extends('layouts.user')

@section('content')
	  <div class="count">
		  <div class="row">
			<div class="col-lg-4 col-7 left">
				<img src="images/0.png" alt="">
			</div>
			<div class="col-lg-8  col-5" id="loop">
				<img src="images/1.png" alt="">
				<img src="images/2.png" alt="">
				<img src="images/3.png" alt="">
				<img src="images/4.png" alt="">
			</div>
			  <div class="col-lg-8 col-5" id="loop">
				  <img src="images/1.png" alt="">
				  <img src="images/2.png" alt="">
				  <img src="images/3.png" alt="">
				  <img src="images/4.png" alt="">
			  </div>
			  <div class="col-lg-4 col-7 right">
				  <img src="images/0.png" alt="">
			  </div>
			  <div class="col-lg-4 col-7 left">
				  <img src="images/0.png" alt="">
			  </div>
			  <div class="col-lg-8  col-5" id="loop">
				  <img src="images/1.png" alt="">
				  <img src="images/2.png" alt="">
				  <img src="images/3.png" alt="">
				  <img src="images/4.png" alt="">
			  </div>
			  <div class="col-lg-8 col-5" id="loop">
				  <img src="images/1.png" alt="">
				  <img src="images/2.png" alt="">
				  <img src="images/3.png" alt="">
				  <img src="images/4.png" alt="">
			  </div>
			  <div class="col-lg-4 col-7 right">
				  <img src="images/0.png" alt="">
			  </div>
			  <div class="col-lg-4 col-7 left">
				  <img src="images/0.png" alt="">
			  </div>
			  <div class="col-lg-8  col-5" id="loop">
				  <img src="images/1.png" alt="">
				  <img src="images/2.png" alt="">
				  <img src="images/3.png" alt="">
				  <img src="images/4.png" alt="">
			  </div>
			  <div class="col-lg-8 col-5" id="loop">
				  <img src="images/1.png" alt="">
				  <img src="images/2.png" alt="">
				  <img src="images/3.png" alt="">
				  <img src="images/4.png" alt="">
			  </div>
			  <div class="col-lg-4 col-7 right">
				  <img src="images/0.png" alt="">
			  </div>
	  </div>


	  </div>

@endsection
